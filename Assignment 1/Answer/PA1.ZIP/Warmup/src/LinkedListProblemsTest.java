import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class LinkedListProblemsTest {

    ListNode T;
    
    @Before
    public void setUp() throws Exception {
        int[] testdata = {1,1,2,3,3};
        T = new ListNode(testdata[0]);
        ListNode current = T;
        for (int i = 1; i < testdata.length; i++) {
            current.next = new ListNode(testdata[i]);
            current = current.next;
        }
    }

    @Test
    public void testDeleteDuplicates() {
        int[] expected = {1,2,3};
        ListNode newT = LinkedListProblems.deleteDuplicates(T);
        
        ListNode p = newT;
        int i = 0;
        while (p != null) {
            assertEquals(expected[i], p.val);
            i = i + 1;
            p = p.next;
        }
        assertEquals(expected.length, i);
    }
    
    @Test
    public void testReverseList() {
        int[] expected = {3,3,2,1,1};
        ListNode reversedT = LinkedListProblems.reverseList(T);
        
        ListNode p = reversedT;
        int i = 0;
        while (p != null) {
            assertEquals(expected[i], p.val);
            i = i + 1;
            p = p.next;
        }
        assertEquals(expected.length, i);
    }
}
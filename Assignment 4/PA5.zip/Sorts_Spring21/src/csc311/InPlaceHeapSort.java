package csc311;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

    @Override
    public void sort(K[] array) {
        // Step 1: Build a max heap from the input array.
        // Start from the last non-leaf node and heapify each node going upwards.
        for (int i = array.length / 2 - 1; i >= 0; i--) {
            heapify(array, array.length, i);
        }

        System.out.println("Max heap created: ");
        printArray(array);

        // Step 2: Extract elements from the heap one by one.
        // Swap the root (largest element) with the last element and reduce heap size.
        for (int i = array.length - 1; i > 0; i--) {
            swap(array, 0, i); // Move the largest element to the end of the array.
            System.out.println("Swapped " + array[i] + " with root, current array: ");
            printArray(array);

            // Rebuild the heap with the reduced size.
            heapify(array, i, 0);
        }

        System.out.println("Array sorted using Heap Sort: ");
        printArray(array);
    }

    // Reorganize the subtree rooted at rootIndex into a max heap.
    private void heapify(K[] array, int size, int rootIndex) {
        int largest = rootIndex; // Assume the root is the largest.
        int leftChild = 2 * rootIndex + 1; // Index of left child.
        int rightChild = 2 * rootIndex + 2; // Index of right child.

        // Check if the left child exists and is greater than the root.
        if (leftChild < size && array[leftChild].compareTo(array[largest]) > 0) {
            largest = leftChild;
        }

        // Check if the right child exists and is greater than the current largest.
        if (rightChild < size && array[rightChild].compareTo(array[largest]) > 0) {
            largest = rightChild;
        }

        // If the largest is not the root, swap and continue heapifying.
        if (largest != rootIndex) {
            swap(array, rootIndex, largest);
            System.out.println("Heapify: Swapped " + array[rootIndex] + " with " + array[largest]);
            printArray(array);

            // Recursively heapify the affected subtree.
            heapify(array, size, largest);
        }
    }

    // Swap two elements in the array.
    private void swap(K[] array, int i, int j) {
        K temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // Utility method to print the array.
    private void printArray(K[] array) {
        for (K element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}

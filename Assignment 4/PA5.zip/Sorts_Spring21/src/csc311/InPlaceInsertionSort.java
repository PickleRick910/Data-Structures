package csc311;

public class InPlaceInsertionSort<K extends Comparable<K>> implements Sorter<K> {

    @Override
    public void sort(K[] array) {
        System.out.println("Starting Insertion Sort...");
        printArray(array);

        // Start from the second element since the first element is trivially sorted
        for (int i = 1; i < array.length; i++) {
            K key = array[i]; // The element to be inserted in the sorted part
            int j = i - 1;

            System.out.println("Current key: " + key);

            // Shift elements of the sorted portion to the right to make space for the key
            while (j >= 0 && array[j].compareTo(key) > 0) {
                System.out.println("Moving " + array[j] + " to position " + (j + 1));
                array[j + 1] = array[j];
                j--;
            }

            // Insert the key into its correct position
            array[j + 1] = key;
            System.out.println("Inserted key " + key + " at position " + (j + 1));
            printArray(array); // Print the array after each insertion
        }

        System.out.println("Array sorted using Insertion Sort:");
        printArray(array);
    }

    // Utility method to print the array
    private void printArray(K[] array) {
        for (K element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}

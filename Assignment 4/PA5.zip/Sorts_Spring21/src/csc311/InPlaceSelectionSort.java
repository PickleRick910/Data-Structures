package csc311;

public class InPlaceSelectionSort<K extends Comparable<K>> implements Sorter<K> {

    @Override
    public void sort(K[] array) {
        System.out.println("Starting Selection Sort...");
        printArray(array);

        // Traverse through all array elements
        for (int i = 0; i < array.length - 1; i++) {
            int minIndex = i; // Assume the first element is the smallest
            System.out.println("Starting iteration " + (i + 1) + ", looking for the smallest element from index " + i);

            // Find the smallest element in the remaining unsorted part of the array
            for (int j = i + 1; j < array.length; j++) {
                if (array[j].compareTo(array[minIndex]) < 0) {
                    minIndex = j; // Update minIndex if a smaller element is found
                }
            }

            // Swap the found minimum element with the first element in the unsorted part
            if (minIndex != i) {
                System.out.println("Swapping " + array[i] + " with " + array[minIndex]);
                swap(array, i, minIndex);
            } else {
                System.out.println("No swap needed for this iteration.");
            }

            printArray(array); // Print the array after each iteration
        }

        System.out.println("Array sorted using Selection Sort:");
        printArray(array);
    }

    // Utility method to swap two elements in the array
    private void swap(K[] array, int i, int j) {
        K temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // Utility method to print the array
    private void printArray(K[] array) {
        for (K element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}

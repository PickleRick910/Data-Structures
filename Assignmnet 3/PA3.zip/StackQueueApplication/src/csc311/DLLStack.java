package csc311;

import net.datastructures.Stack;

/**
 * A stack implementation using a doubly linked list as the underlying data structure.
 * This stack supports standard stack operations such as push, pop, and top.
 * 
 * @param <E> The type of elements stored in the stack
 */
public class DLLStack<E> implements Stack<E> {

    // The doubly linked list to hold stack elements
    private DoublyLinkedList<E> list;

    /**
     * Constructs an empty stack.
     */
    public DLLStack() {
        list = new DoublyLinkedList<>(); // Initialize the underlying doubly linked list
    }

    /**
     * Returns the number of elements in the stack.
     *
     * @return the size of the stack
     */
    @Override
    public int size() {
        return list.size();
    }

    /**
     * Checks whether the stack is empty.
     *
     * @return true if the stack contains no elements, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Pushes an element onto the top of the stack.
     *
     * @param e the element to be added
     */
    @Override
    public void push(E e) {
        list.addFirst(e); // Add the element to the front of the doubly linked list
    }

    /**
     * Retrieves the top element of the stack without removing it.
     *
     * @return the top element, or null if the stack is empty
     */
    @Override
    public E top() {
        if (isEmpty()) {
            return null; // Return null if the stack is empty
        }
        return list.first().getElement(); // Get the element at the front of the list
    }

    /**
     * Removes and returns the top element of the stack.
     *
     * @return the top element, or null if the stack is empty
     */
    @Override
    public E pop() {
        if (isEmpty()) {
            return null; // Return null if the stack is empty
        }
        return list.removeFirst(); // Remove and return the front element of the list
    }
}

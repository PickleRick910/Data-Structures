package csc311;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * A test suite for the DLLStack class.
 */
public class DLLStackTest {

    private DLLStack<Integer> stack;

    /**
     * Sets up the test environment by initializing an empty stack before each test.
     */
    @Before
    public void setUp() throws Exception {
        stack = new DLLStack<>();
    }

    /**
     * Tests the push and pop operations to ensure elements are correctly added and removed.
     */
    @Test
    public void testPushAndPop() {
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Verify that elements are removed in reverse order of insertion
        assertEquals((Integer) 30, stack.pop());
        assertEquals((Integer) 20, stack.pop());
        assertEquals((Integer) 10, stack.pop());

        // Ensure the stack is empty after all elements are removed
        assertTrue(stack.isEmpty());
    }

    /**
     * Tests the top operation to verify it returns the correct element without removing it.
     */
    @Test
    public void testTop() {
        stack.push(5);
        stack.push(15);

        // Verify the top element is the most recently added
        assertEquals((Integer) 15, stack.top());
        assertEquals(2, stack.size()); // Ensure top does not remove the element
    }

    /**
     * Tests the isEmpty method to confirm it accurately detects an empty stack.
     */
    @Test
    public void testIsEmpty() {
        assertTrue(stack.isEmpty()); // Initially, the stack should be empty

        stack.push(1); // Add an element
        assertFalse(stack.isEmpty()); // Stack is no longer empty
    }

    /**
     * Tests the size method to ensure it returns the correct number of elements in the stack.
     */
    @Test
    public void testSize() {
        assertEquals(0, stack.size()); // Verify initial size is 0

        stack.push(2);
        stack.push(4);
        assertEquals(2, stack.size()); // Verify size after adding two elements

        stack.pop();
        assertEquals(1, stack.size()); // Verify size after removing one element
    }

    /**
     * Tests the pop operation when the stack is empty to ensure it returns null.
     */
    @Test
    public void testPopFromEmptyStack() {
        assertNull(stack.pop()); // Popping from an empty stack should return null
    }

    /**
     * Tests the top operation when the stack is empty to ensure it returns null.
     */
    @Test
    public void testTopFromEmptyStack() {
        assertNull(stack.top()); // Top of an empty stack should return null
    }
}

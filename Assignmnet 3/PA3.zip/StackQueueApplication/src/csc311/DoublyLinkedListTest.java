package csc311;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class DoublyLinkedListTest {

    private DoublyLinkedList<String> list;

    @Before
    public void setUp() {
        list = new DoublyLinkedList<>();
    }

    @Test
    public void testAddFirstAndRemoveFirst() {
        list.addFirst("A");
        list.addFirst("B");
        assertEquals(2, list.size());
        assertEquals("B", list.removeFirst());
        assertEquals("A", list.removeFirst());
        assertTrue(list.isEmpty());
    }

    @Test
    public void testAddLastAndRemoveLast() {
        list.addLast("A");
        list.addLast("B");
        assertEquals(2, list.size());
        assertEquals("B", list.removeLast());
        assertEquals("A", list.removeLast());
        assertTrue(list.isEmpty());
    }

    @Test
    public void testIteration() {
        list.addLast("A");
        list.addLast("B");
        list.addLast("C");

        StringBuilder result = new StringBuilder();
        for (String s : list) {
            result.append(s);
        }

        assertEquals("ABC", result.toString());
    }

    @Test(expected = IllegalStateException.class)
    public void testRemoveFromEmptyList() {
        list.removeFirst();
    }
}

package csc311;

/**
 * A utility class to convert infix expressions to postfix notation.
 * Infix notation is the standard mathematical format (e.g., "3 + 4").
 * Postfix notation places operators after operands (e.g., "3 4 +").
 */
public class InfixToPostfix {

    /**
     * Converts an infix expression to a postfix expression.
     * 
     * @param infixExp The infix expression as a string, with tokens separated by spaces.
     *                 For example: "3 + 4 * 2".
     * @return The equivalent postfix expression as a string.
     */
    public static String convert(String infixExp) {
        // Stack to hold operators and parentheses
        DLLStack<String> stack = new DLLStack<>();
        // StringBuilder to construct the resulting postfix expression
        StringBuilder result = new StringBuilder();

        // Split the infix expression into tokens (operands, operators, and parentheses)
        String[] tokens = infixExp.split(" ");

        // Process each token in the infix expression
        for (String token : tokens) {
            if (isOperand(token)) {
                // If the token is an operand, add it directly to the result
                result.append(token).append(" ");
            } else if (token.equals("(")) {
                // If the token is an opening parenthesis, push it onto the stack
                stack.push(token);
            } else if (token.equals(")")) {
                // If the token is a closing parenthesis, pop operators until '(' is found
                while (!stack.isEmpty() && !stack.top().equals("(")) {
                    result.append(stack.pop()).append(" ");
                }
                stack.pop(); // Remove the opening parenthesis
            } else {
                // For operators, pop higher or equal precedence operators from the stack
                while (!stack.isEmpty() && getPrecedence(stack.top()) >= getPrecedence(token)) {
                    result.append(stack.pop()).append(" ");
                }
                stack.push(token); // Push the current operator onto the stack
            }
        }

        // Pop any remaining operators from the stack and add them to the result
        while (!stack.isEmpty()) {
            result.append(stack.pop()).append(" ");
        }

        // Return the resulting postfix expression as a trimmed string
        return result.toString().trim();
    }

    /**
     * Determines if a token is an operand (number).
     * 
     * @param token The token to check.
     * @return true if the token is an operand; false otherwise.
     */
    private static boolean isOperand(String token) {
        // Check if the token is a numeric value
        return token.matches("\\d+");
    }

    /**
     * Determines the precedence of an operator.
     * 
     * @param operator The operator as a string.
     * @return The precedence level of the operator. Higher numbers indicate higher precedence.
     */
    private static int getPrecedence(String operator) {
        // Define precedence levels for operators
        switch (operator) {
            case "+":
            case "-":
                return 1; // Lowest precedence
            case "*":
            case "/":
                return 2; // Higher precedence
            default:
                return 0; // Non-operators have no precedence
        }
    }
}

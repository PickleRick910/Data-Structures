package csc311;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * A test suite for the InfixToPostfix class.
 * Verifies the correctness of the conversion from infix to postfix notation.
 */
public class InfixToPostfixTest {

    /**
     * Sets up the test environment.
     */
    @Before
    public void setUp() throws Exception {
        // No setup required for static methods
    }

    /**
     * Tests a simple addition conversion.
     */
    @Test
    public void testConvert1() {
        assertEquals("3 4 +", InfixToPostfix.convert("3 + 4"));
    }

    /**
     * Tests conversion with parentheses and addition/multiplication.
     */
    @Test
    public void testConvert2() {
        assertEquals("3 4 5 + *", InfixToPostfix.convert("3 * ( 4 + 5 )"));
    }

    /**
     * Tests precedence of multiplication over addition.
     */
    @Test
    public void testConvert3() {
        assertEquals("2 3 4 * +", InfixToPostfix.convert("2 + 3 * 4"));
    }

    /**
     * Tests conversion with nested parentheses and mixed operators.
     */
    @Test
    public void testConvert4() {
        assertEquals("4 5 6 * + 7 -", InfixToPostfix.convert("( 4 + 5 * 6 ) - 7"));
    }

    /**
     * Tests conversion with two sets of parentheses.
     */
    @Test
    public void testConvert5() {
        assertEquals("1 2 + 3 4 + *", InfixToPostfix.convert("( 1 + 2 ) * ( 3 + 4 )"));
    }

    /**
     * Tests a more complex expression with parentheses, addition, and subtraction.
     */
    @Test
    public void testConvert6() {
        assertEquals("5 1 2 + 4 * + 3 -", InfixToPostfix.convert("5 + ( 1 + 2 ) * 4 - 3"));
    }

    /**
     * Tests a conversion with mixed operations and no parentheses.
     */
    @Test
    public void testConvert7() {
        assertEquals("10 2 8 * + 3 -", InfixToPostfix.convert("10 + 2 * 8 - 3"));
    }

    /**
     * Tests a conversion with multiple sets of parentheses.
     */
    @Test
    public void testConvert8() {
        assertEquals("2 3 + 4 5 * +", InfixToPostfix.convert("( 2 + 3 ) + ( 4 * 5 )"));
    }
}

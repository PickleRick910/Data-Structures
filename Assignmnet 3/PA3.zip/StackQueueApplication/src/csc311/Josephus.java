package csc311;

public class Josephus {

    /**
     * Simulates the Josephus problem using a circular queue.
     * 
     * The Josephus problem is a counting game in which people are arranged in a circle,
     * and every k-th person is removed from the circle until only one remains.
     * This method determines the elimination sequence and the eventual winner.
     *
     * @param persons an array of strings representing the names of all participants.
     * @param k       an integer specifying the step count for elimination.
     * @return a DoublyLinkedList containing the elimination sequence and the winner as the last element.
     */
    public DoublyLinkedList<String> order(String[] persons, int k) {
        // A queue to represent the circle of players
        CircularArrayQueue<String> queue = new CircularArrayQueue<>(persons.length);

        // A list to record the elimination sequence and winner
        DoublyLinkedList<String> result = new DoublyLinkedList<>();

        // Populate the queue with all players
        for (String person : persons) {
            queue.enqueue(person);
        }

        // Keep eliminating players until only one is left in the queue
        while (queue.size() > 1) {
            // Move the first (k-1) players to the back of the queue
            for (int i = 0; i < k - 1; i++) {
                queue.enqueue(queue.dequeue());
            }

            // Remove the k-th player from the circle and add them to the result
            String eliminated = queue.dequeue();
            System.out.println("Eliminated: " + eliminated); // Log the elimination for debugging
            result.addLast(eliminated);
        }

        // Add the final remaining player as the winner
        String winner = queue.dequeue();
        System.out.println("Winner: " + winner); // Log the winner for debugging
        result.addLast(winner);

        // Return the elimination order along with the winner
        return result;
    }
}

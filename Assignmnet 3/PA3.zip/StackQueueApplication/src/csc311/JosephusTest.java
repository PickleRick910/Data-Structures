package csc311;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class JosephusTest {

    // Instance of the Josephus class to test
    private Josephus josephus;

    /**
     * Sets up the test environment before each test case is run.
     */
    @Before
    public void setUp() throws Exception {
        josephus = new Josephus(); // Create a new instance of Josephus before each test
    }

    /**
     * Test case for a scenario with 5 players and step size 3.
     * Verifies the order of elimination and the final winner.
     */
    @Test
    public void testOrder1() {
        // Input: 5 players, k = 3
        String[] players = {"Alice", "Bob", "Charlie", "David", "Eve"};
        int k = 3;

        // Run the Josephus algorithm
        DoublyLinkedList<String> result = josephus.order(players, k);

        // Assert the expected elimination order and winner
        assertEquals("Charlie", result.removeFirst());
        assertEquals("Alice", result.removeFirst());
        assertEquals("Eve", result.removeFirst());
        assertEquals("Bob", result.removeFirst());
        assertEquals("David", result.removeFirst()); // Winner
    }

    /**
     * Test case for a scenario with 4 players and step size 2.
     * Checks if the elimination order and the final winner are correct.
     */
    @Test
    public void testOrder2() {
        // Input: 4 players, k = 2
        String[] players = {"Anna", "Bella", "Cody", "Duke"};
        int k = 2;

        // Run the Josephus algorithm
        DoublyLinkedList<String> result = josephus.order(players, k);

        // Assert the expected elimination order and winner
        assertEquals("Bella", result.removeFirst());
        assertEquals("Duke", result.removeFirst());
        assertEquals("Cody", result.removeFirst());
        assertEquals("Anna", result.removeFirst()); // Winner
    }

    /**
     * Test case for a single player.
     * Ensures the single player is correctly identified as the winner.
     */
    @Test
    public void testOrder3() {
        // Input: 1 player, k = 1
        String[] players = {"John"};
        int k = 1;

        // Run the Josephus algorithm
        DoublyLinkedList<String> result = josephus.order(players, k);

        // Assert that the single player is the winner
        assertEquals("John", result.removeFirst());
    }

    /**
     * Test case with 5 players and step size 1.
     * Verifies that players are eliminated in the same order as given.
     */
    @Test
    public void testOrder4() {
        // Input: 5 players, k = 1
        String[] players = {"Alice", "Bob", "Charlie", "David", "Eve"};
        int k = 1;

        // Run the Josephus algorithm
        DoublyLinkedList<String> result = josephus.order(players, k);

        // Assert the expected elimination order and winner
        assertEquals("Alice", result.removeFirst());
        assertEquals("Bob", result.removeFirst());
        assertEquals("Charlie", result.removeFirst());
        assertEquals("David", result.removeFirst());
        assertEquals("Eve", result.removeFirst()); // Winner
    }
}

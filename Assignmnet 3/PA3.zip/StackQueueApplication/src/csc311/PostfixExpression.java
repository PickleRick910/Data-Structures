package csc311;

/**
 * A utility class for evaluating postfix expressions.
 * Postfix notation (also known as Reverse Polish Notation) involves placing operators 
 * after their operands. For example:
 * - Infix: (5 + 10)
 * - Postfix: 5 10 +
 * 
 * This class uses a stack-based approach to evaluate postfix expressions.
 */
public class PostfixExpression {

    /**
     * Evaluates a given postfix expression and returns the result.
     * 
     * @param exp The postfix expression as a string, with tokens separated by spaces.
     *            For example, "5 10 + 3 *".
     * @return The result of evaluating the postfix expression.
     */
    public static int evaluate(String exp) {
        // Stack to store intermediate results
        DLLStack<Integer> stack = new DLLStack<>();
        // Split the expression into individual tokens (operands and operators)
        String[] tokens = exp.split(" ");

        // Iterate through each token in the expression
        for (String token : tokens) {
            if (isOperator(token)) {
                // If the token is an operator, pop two operands from the stack
                int b = stack.pop();
                int a = stack.pop();
                // Apply the operator and push the result back onto the stack
                stack.push(applyOperator(token, a, b));
            } else {
                // If the token is a number, parse it and push onto the stack
                stack.push(Integer.parseInt(token));
            }
        }

        // The final result will be the only remaining value in the stack
        return stack.pop();
    }

    /**
     * Checks if a given token is a valid operator.
     * 
     * @param token A string token to check.
     * @return true if the token is an operator (+, -, *, /); false otherwise.
     */
    private static boolean isOperator(String token) {
        return "+-*/".contains(token); // Valid operators are +, -, *, /
    }

    /**
     * Applies an operator to two operands and returns the result.
     * 
     * @param operator The operator as a string.
     * @param a        The first operand.
     * @param b        The second operand.
     * @return The result of applying the operator to the operands.
     * @throws IllegalArgumentException if the operator is invalid.
     */
    private static int applyOperator(String operator, int a, int b) {
        switch (operator) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                return a / b; // Integer division
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }
}

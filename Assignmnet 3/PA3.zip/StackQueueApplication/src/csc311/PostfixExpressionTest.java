package csc311;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * A test suite for the PostfixExpression class.
 * Ensures the correctness of postfix expression evaluation for various scenarios.
 */
public class PostfixExpressionTest {

    /**
     * Sets up the test environment.
     */
    @Before
    public void setUp() throws Exception {
        // No setup needed for static methods
    }

    /**
     * Tests the evaluation of a simple addition expression.
     */
    @Test
    public void testEvaluate1() {
        assertEquals(15, PostfixExpression.evaluate("5 10 +")); // 5 + 10 = 15
    }

    /**
     * Tests the evaluation of a multiplication expression.
     */
    @Test
    public void testEvaluate2() {
        assertEquals(30, PostfixExpression.evaluate("10 3 *")); // 10 * 3 = 30
    }

    /**
     * Tests a complex nested expression.
     */
    @Test
    public void testEvaluate3() {
        assertEquals(14, PostfixExpression.evaluate("5 1 2 + 4 * + 3 -")); 
        // Equivalent to: 5 + (1 + 2) * 4 - 3 = 14
    }

    /**
     * Tests an expression with multiple operations.
     */
    @Test
    public void testEvaluate4() {
        assertEquals(19, PostfixExpression.evaluate("2 3 + 4 * 1 -")); 
        // Equivalent to: (2 + 3) * 4 - 1 = 19
    }

    /**
     * Tests integer division in postfix expressions.
     */
    @Test
    public void testEvaluate5() {
        assertEquals(3, PostfixExpression.evaluate("10 3 /")); // 10 / 3 = 3 (integer division)
    }

    /**
     * Tests a simple addition expression.
     */
    @Test
    public void testEvaluate6() {
        assertEquals(8, PostfixExpression.evaluate("3 5 +")); // 3 + 5 = 8
    }

    /**
     * Tests a simple subtraction expression.
     */
    @Test
    public void testEvaluate7() {
        assertEquals(-2, PostfixExpression.evaluate("3 5 -")); // 3 - 5 = -2
    }

    /**
     * Tests a multiplication operation.
     */
    @Test
    public void testEvaluate8() {
        assertEquals(24, PostfixExpression.evaluate("3 8 *")); // 3 * 8 = 24
    }
}

package csc311;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class JosephusTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testOrder1() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testOrder2() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testOrder3() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testOrder4() {
		fail("Not yet implemented"); // TODO
	}

}

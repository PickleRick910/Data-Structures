package csc311;

public interface Sorter<E> {
	public void sort(E[] array);
}

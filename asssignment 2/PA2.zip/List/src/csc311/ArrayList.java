package csc311;

import java.util.Iterator;
import net.datastructures.List;

/**
 * A simple ArrayList implementation that grows as needed.
 */ 
public class ArrayList<E> implements List<E> {
    // Store our elements
    private E[] data;
    // Keep track of how many elements we have
    private int size;
    // Start with size 16
    private static final int CAPACITY = 16;
    
    // Constructor - create empty list
 // Constructor - create empty list
    @SuppressWarnings("unchecked")  // Adding this annotation here too
    public ArrayList() {
        data = (E[]) new Object[CAPACITY];
        size = 0;
    }
    
    // Get current size
    @Override
    public int size() {
        return size;
    }
    
    // Check if list is empty
    @Override
    public boolean isEmpty() {
        return size == 0;
    }
    
    // Get element at index i
    @Override
    public E get(int i) throws IndexOutOfBoundsException {
        if(i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Index " + i + " is invalid");
        }
        return data[i];
    }
    
    // Change element at index i
    @Override
    public E set(int i, E e) throws IndexOutOfBoundsException {
        if(i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Index " + i + " is invalid");
        }
        E temp = data[i];
        data[i] = e;
        return temp;
    }
    
 // Make array bigger when needed
    @SuppressWarnings("unchecked")  // Adding this annotation to suppress the warning
    private void makeArrayBigger() {
        E[] bigger = (E[]) new Object[data.length * 2];
        for(int i = 0; i < size; i++) {
            bigger[i] = data[i];
        }
        data = bigger;
    }
    
    // Add element at specific position
    @Override
    public void add(int i, E e) throws IndexOutOfBoundsException {
        if(i < 0 || i > size) {
            throw new IndexOutOfBoundsException("Index " + i + " is invalid");
        }
        
        // Make array bigger if needed
        if(size == data.length) {
            makeArrayBigger();
        }
        
        // Move elements over
        for(int j = size - 1; j >= i; j--) {
            data[j + 1] = data[j];
        }
        
        data[i] = e;
        size++;
    }
    
    // Remove element at index i
    @Override
    public E remove(int i) throws IndexOutOfBoundsException {
        if(i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Index " + i + " is invalid");
        }
        
        E removed = data[i];
        
        // Move elements over
        for(int j = i; j < size - 1; j++) {
            data[j] = data[j + 1];
        }
        
        data[size - 1] = null;
        size--;
        return removed;
    }
    
    // Iterator for going through list
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private int pos = 0;
            
            public boolean hasNext() {
                return pos < size;
            }
            
            public E next() {
                return data[pos++];
            }
        };
    }
    
    // Add to front of list
    public void addFirst(E e) {
        add(0, e);
    }
    
    // Add to end of list
    public void addLast(E e) {
        add(size, e);
    }
    
    // Remove from front
    public E removeFirst() throws IndexOutOfBoundsException {
        if(isEmpty()) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        return remove(0);
    }
    
    // Remove from end
    public E removeLast() throws IndexOutOfBoundsException {
        if(isEmpty()) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        return remove(size - 1);
    }
    
    // Get array capacity
    public int capacity() {
        return data.length;
    }
}
package csc311;

/**
 * Simple test cases for ArrayList implementation
 */
public class ArrayListTest {
    public static void main(String[] args) {
        // Test 1: Basic Operations
        System.out.println("=== Test 1: Basic Operations ===");
        ArrayList<String> list1 = new ArrayList<>();
        
        // Test isEmpty and size
        System.out.println("Empty? " + list1.isEmpty());  // Should print: true
        System.out.println("Size: " + list1.size());      // Should print: 0
        
        // Test adding elements
        list1.add(0, "First");
        list1.add(1, "Second");
        list1.add(2, "Third");
        System.out.println("Size after adding: " + list1.size());  // Should print: 3
        System.out.println("Empty? " + list1.isEmpty());          // Should print: false
        
        // Test get and set
        System.out.println("Element at 1: " + list1.get(1));  // Should print: Second
        String old = list1.set(1, "Modified");
        System.out.println("Old element: " + old);            // Should print: Second
        System.out.println("New element: " + list1.get(1));   // Should print: Modified
        
        // Test 2: Numbers and Iteration
        System.out.println("\n=== Test 2: Numbers and Iteration ===");
        ArrayList<Integer> list2 = new ArrayList<>();
        
        // Add numbers
        for(int i = 0; i < 5; i++) {
            list2.add(i, i * 10);
        }
        
        // Test iterator
        System.out.print("Elements: ");
        for(Integer num : list2) {
            System.out.print(num + " ");  // Should print: 0 10 20 30 40
        }
        System.out.println();
        
        // Test 3: First/Last Operations
        System.out.println("\n=== Test 3: First/Last Operations ===");
        ArrayList<Character> list3 = new ArrayList<>();
        
        // Test addFirst and addLast
        list3.addFirst('A');
        list3.addLast('B');
        list3.addFirst('C');
        list3.addLast('D');
        
        System.out.print("After adds: ");
        for(char c : list3) {
            System.out.print(c + " ");  // Should print: C A B D
        }
        System.out.println();
        
        // Test removeFirst and removeLast
        char first = list3.removeFirst();
        char last = list3.removeLast();
        System.out.println("Removed first: " + first);  // Should print: C
        System.out.println("Removed last: " + last);    // Should print: D
        
        // Test capacity
        System.out.println("\n=== Test 4: Capacity ===");
        ArrayList<Integer> list4 = new ArrayList<>();
        System.out.println("Initial capacity: " + list4.capacity());  // Should print: 16
        
        // Fill beyond initial capacity to test doubling
        for(int i = 0; i < 20; i++) {
            list4.add(i, i);
        }
        System.out.println("Capacity after adding 20 elements: " + list4.capacity());  // Should print: 32
        
        // Test error handling
        System.out.println("\n=== Test 5: Error Handling ===");
        try {
            list4.get(100);  // Should throw exception
        } catch(IndexOutOfBoundsException e) {
            System.out.println("Successfully caught invalid get: " + e.getMessage());
        }
        
        try {
            list4.add(-1, 5);  // Should throw exception
        } catch(IndexOutOfBoundsException e) {
            System.out.println("Successfully caught invalid add: " + e.getMessage());
        }
    }
}
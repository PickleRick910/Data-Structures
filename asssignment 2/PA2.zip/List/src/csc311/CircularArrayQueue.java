package csc311;

import net.datastructures.Queue;

/**
 * A ring-buffer implementation of a queue that uses a circular array.
 * This structure efficiently manages space by reusing empty positions,
 * making it ideal for fixed-size queue operations.
 *
 * @param <E> the type of elements stored in this queue
 */
public class CircularArrayQueue<E> implements Queue<E> {
    
    // Instance variables with meaningful names
    private E[] ringBuffer;           // The circular storage array
    private int headIndex = 0;        // Points to the first element
    private int elementCount = 0;     // Tracks number of elements
    private static final int DEFAULT_CAPACITY = 10;  // Default size if none specified
    
    /**
     * Creates a new queue with specified capacity.
     * 
     * @param initialCapacity desired size of the queue
     * @throws IllegalArgumentException if capacity is negative
     */
    @SuppressWarnings("unchecked")
    public CircularArrayQueue(int initialCapacity) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("Queue capacity must be non-negative");
        }
        // Create the buffer with the specified size
        ringBuffer = (E[]) new Object[initialCapacity];
    }
    
    /**
     * Creates a queue with default capacity.
     */
    public CircularArrayQueue() {
        this(DEFAULT_CAPACITY);
    }
    
    @Override
    public int size() {
        return elementCount;
    }
    
    @Override
    public boolean isEmpty() {
        return elementCount == 0;
    }
    
    /**
     * Determines if the queue has reached its capacity.
     * 
     * @return true if queue is full, false otherwise
     */
    private boolean isFull() {
        return elementCount == ringBuffer.length;
    }
    
    @Override
    public void enqueue(E newElement) {
        if (newElement == null) {
            throw new IllegalArgumentException("Cannot add null element to queue");
        }
        if (isFull()) {
            throw new IllegalStateException("Queue has reached its capacity of " + ringBuffer.length);
        }
        
        // Calculate the next available position using modular arithmetic
        int insertPosition = (headIndex + elementCount) % ringBuffer.length;
        ringBuffer[insertPosition] = newElement;
        elementCount++;
    }
    
    @Override
    public E first() {
        if (isEmpty()) {
            return null;
        }
        return ringBuffer[headIndex];
    }
    
    @Override
    public E dequeue() {
        if (isEmpty()) {
            return null;
        }
        
        // Get the element at the head of the queue
        E removedElement = ringBuffer[headIndex];
        
        // Clear the reference and update head
        ringBuffer[headIndex] = null;  // Help garbage collection
        headIndex = (headIndex + 1) % ringBuffer.length;
        elementCount--;
        
        return removedElement;
    }
    
    /**
     * Provides a string representation of the queue's contents.
     * Useful for debugging and visualization.
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }
        
        StringBuilder result = new StringBuilder("[");
        int current = headIndex;
        
        // Iterate through all elements
        for (int i = 0; i < elementCount; i++) {
            result.append(ringBuffer[current]);
            if (i < elementCount - 1) {
                result.append(", ");
            }
            current = (current + 1) % ringBuffer.length;
        }
        
        return result.append("]").toString();
    }
    
    /**
     * Returns the maximum number of elements this queue can hold.
     * 
     * @return the capacity of the queue
     */
    public int getCapacity() {
        return ringBuffer.length;
    }
    
    /**
     * Removes all elements from the queue.
     */
    public void clear() {
        // Clear all references
        for (int i = 0; i < ringBuffer.length; i++) {
            ringBuffer[i] = null;
        }
        headIndex = 0;
        elementCount = 0;
    }
}
package csc311;
import java.util.Iterator;
import net.datastructures.Position;
import net.datastructures.PositionalList;

/**
 * An enhanced implementation of a doubly linked list that uses the PositionalList interface.
 * This implementation uses a chain of connected nodes with both forward and backward links,
 * making it efficient for traversal in both directions.
 *
 * @param <E> the type of elements stored in the list
 */
public class DoublyLinkedList<E> implements PositionalList<E> {
    
    // Inner class representing a node in our linked chain
    private static class ListNode<E> implements Position<E> {
        private E data;                // The actual data stored in this node
        private ListNode<E> previous;  // Link to the previous node in the chain
        private ListNode<E> next;      // Link to the next node in the chain
        
        // Creates a new node with given connections
        public ListNode(E data, ListNode<E> previous, ListNode<E> next) {
            this.data = data;
            this.previous = previous;
            this.next = next;
        }
        
        @Override
        public E getElement() throws IllegalStateException {
            if (next == null) { // Check if node has been deleted
                throw new IllegalStateException("Node is no longer valid");
            }
            return data;
        }
        
        // Getters and setters for node connections
        public ListNode<E> getPrevious() { return previous; }
        public ListNode<E> getNext() { return next; }
        public void setPrevious(ListNode<E> prev) { previous = prev; }
        public void setNext(ListNode<E> next) { this.next = next; }
    }
    
    // List management fields
    private ListNode<E> endFront;      // Front sentinel node
    private ListNode<E> endBack;       // Back sentinel node
    private int elementCount = 0;      // Number of elements in the list
    
    /**
     * Creates an empty list with sentinel nodes.
     */
    public DoublyLinkedList() {
        // Create sentinel nodes that mark the boundaries of our list
        endFront = new ListNode<>(null, null, null);
        endBack = new ListNode<>(null, endFront, null);
        endFront.setNext(endBack);
    }
    
    @Override
    public int size() { 
        return elementCount; 
    }
    
    @Override
    public boolean isEmpty() { 
        return elementCount == 0; 
    }
    
    @Override
    public Position<E> first() {
        if (isEmpty()) return null;
        return endFront.getNext();
    }
    
    @Override
    public Position<E> last() {
        if (isEmpty()) return null;
        return endBack.getPrevious();
    }
    
    @Override
    public Position<E> before(Position<E> position) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        ListNode<E> previousNode = node.getPrevious();
        return previousNode == endFront ? null : previousNode;
    }
    
    @Override
    public Position<E> after(Position<E> position) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        ListNode<E> nextNode = node.getNext();
        return nextNode == endBack ? null : nextNode;
    }
    
    @Override
    public Position<E> addFirst(E element) {
        return insertBetween(element, endFront, endFront.getNext());
    }
    
    @Override
    public Position<E> addLast(E element) {
        return insertBetween(element, endBack.getPrevious(), endBack);
    }
    
    @Override
    public Position<E> addBefore(Position<E> position, E element) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        return insertBetween(element, node.getPrevious(), node);
    }
    
    @Override
    public Position<E> addAfter(Position<E> position, E element) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        return insertBetween(element, node, node.getNext());
    }
    
    @Override
    public E set(Position<E> position, E element) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        E oldElement = node.getElement();
        node.data = element;
        return oldElement;
    }
    
    @Override
    public E remove(Position<E> position) throws IllegalArgumentException {
        ListNode<E> node = validatePosition(position);
        
        // Update the connections
        ListNode<E> previousNode = node.getPrevious();
        ListNode<E> nextNode = node.getNext();
        previousNode.setNext(nextNode);
        nextNode.setPrevious(previousNode);
        
        // Clear the node and decrement size
        elementCount--;
        E removedElement = node.getElement();
        
        // Help garbage collection
        node.data = null;
        node.setPrevious(null);
        node.setNext(null);
        
        return removedElement;
    }
    
    /**
     * Removes and returns the first element of the list.
     */
    public E removeFirst() throws IllegalStateException {
        if (isEmpty()) throw new IllegalStateException("List is empty");
        return remove(first());
    }
    
    /**
     * Removes and returns the last element of the list.
     */
    public E removeLast() throws IllegalStateException {
        if (isEmpty()) throw new IllegalStateException("List is empty");
        return remove(last());
    }
    
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private ListNode<E> current = endFront.getNext();
            
            @Override
            public boolean hasNext() {
                return current != endBack;
            }
            
            @Override
            public E next() {
                E result = current.getElement();
                current = current.getNext();
                return result;
            }
        };
    }
    
    @Override
    public Iterable<Position<E>> positions() {
        return () -> new Iterator<Position<E>>() {
            private ListNode<E> current = endFront.getNext();
            
            @Override
            public boolean hasNext() {
                return current != endBack;
            }
            
            @Override
            public Position<E> next() {
                Position<E> result = current;
                current = current.getNext();
                return result;
            }
        };
    }
    
    /**
     * Ensures that a position is valid and returns it as a ListNode.
     */
    private ListNode<E> validatePosition(Position<E> position) throws IllegalArgumentException {
        if (!(position instanceof ListNode)) {
            throw new IllegalArgumentException("Invalid position type");
        }
        
        ListNode<E> node = (ListNode<E>) position;
        
        if (node.getNext() == null) {
            throw new IllegalArgumentException("Position is no longer in the list");
        }
        
        return node;
    }
    
    /**
     * Creates a new node and inserts it between two existing nodes.
     */
    private Position<E> insertBetween(E element, ListNode<E> predecessor, ListNode<E> successor) {
        ListNode<E> newNode = new ListNode<>(element, predecessor, successor);
        predecessor.setNext(newNode);
        successor.setPrevious(newNode);
        elementCount++;
        return newNode;
    }
}
package csc311;

import net.datastructures.Position;

/**
 * Tests DoublyLinkedList implementation using a music playlist manager.
 * Demonstrates navigation and modification of a playlist.
 */
public class PlaylistManagerTest {
    public static void main(String[] args) {
        System.out.println("🎵 Music Playlist Manager Test\n");
        testBasicPlaylistOperations();
        testAdvancedPlaylistFeatures();
    }

    private static void testBasicPlaylistOperations() {
        System.out.println("=== Basic Playlist Operations ===");
        DoublyLinkedList<Song> playlist = new DoublyLinkedList<>();

        // Add initial songs
        System.out.println("\nCreating new playlist...");
        Position<Song> first = playlist.addFirst(new Song("Bohemian Rhapsody", "Queen", 354));
        Position<Song> second = playlist.addLast(new Song("Hotel California", "Eagles", 391));
        playlist.addLast(new Song("Sweet Child O' Mine", "Guns N' Roses", 356));

        // Display playlist
        System.out.println("Initial playlist:");
        displayPlaylist(playlist);

        // Test navigation
        System.out.println("\nTesting playlist navigation:");
        System.out.println("Current song: " + first.getElement());
        System.out.println("Next song: " + playlist.after(first).getElement());
        System.out.println("Previous song from second: " + playlist.before(second).getElement());
    }

    private static void testAdvancedPlaylistFeatures() {
        System.out.println("\n=== Advanced Playlist Features ===");
        DoublyLinkedList<Song> playlist = new DoublyLinkedList<>();

        // Create a longer playlist
        Position<Song> song1 = playlist.addLast(new Song("Yesterday", "The Beatles", 125));
        Position<Song> song2 = playlist.addLast(new Song("Stairway to Heaven", "Led Zeppelin", 482));
        Position<Song> song3 = playlist.addLast(new Song("Purple Rain", "Prince", 520));

        System.out.println("\nOriginal playlist:");
        displayPlaylist(playlist);

        // Test inserting songs at specific positions
        System.out.println("\nAdding songs at specific positions...");
        playlist.addBefore(song2, new Song("Like a Rolling Stone", "Bob Dylan", 373));
        playlist.addAfter(song2, new Song("Imagine", "John Lennon", 183));

        System.out.println("Updated playlist:");
        displayPlaylist(playlist);

        // Test removing and replacing songs
        System.out.println("\nModifying playlist...");
        System.out.println("Removing: " + playlist.remove(song3));
        playlist.set(song1, new Song("Hey Jude", "The Beatles", 431));

        System.out.println("\nFinal playlist:");
        displayPlaylist(playlist);

        // Test shuffle feature
        System.out.println("\nTesting shuffle feature...");
        shufflePlaylist(playlist);
        System.out.println("Shuffled playlist:");
        displayPlaylist(playlist);
    }

    private static void shufflePlaylist(DoublyLinkedList<Song> playlist) {
        // Simple shuffle simulation - just reverses the playlist
        DoublyLinkedList<Song> shuffled = new DoublyLinkedList<>();
        Position<Song> current = playlist.last();
        
        while (current != null) {
            shuffled.addLast(playlist.remove(current));
            current = playlist.last();
        }
        
        // Copy back to original playlist
        for (Song song : shuffled) {
            playlist.addLast(song);
        }
    }

    private static void displayPlaylist(DoublyLinkedList<Song> playlist) {
        int trackNumber = 1;
        for (Song song : playlist) {
            System.out.printf("%d. %s\n", trackNumber++, song);
        }
    }

    // Inner class to represent a song
    private static class Song {
        private String title;
        private String artist;
        private int duration; // in seconds

        public Song(String title, String artist, int duration) {
            this.title = title;
            this.artist = artist;
            this.duration = duration;
        }

        @Override
        public String toString() {
            return String.format("%s - %s (%d:%02d)", 
                title, artist, duration/60, duration%60);
        }
    }
}
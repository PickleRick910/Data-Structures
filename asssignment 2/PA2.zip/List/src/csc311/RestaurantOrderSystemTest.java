package csc311;

/**
 * Tests CircularArrayQueue implementation using a restaurant order system simulation.
 * Demonstrates practical usage in a food service context.
 */
public class RestaurantOrderSystemTest {
    public static void main(String[] args) {
        System.out.println("🍽️ Restaurant Order Processing System Test\n");
        testOrderQueue();
        testPeakHourOperations();
    }

    private static void testOrderQueue() {
        System.out.println("=== Basic Order Processing Test ===");
        CircularArrayQueue<Order> orderQueue = new CircularArrayQueue<>(5);

        try {
            // Simulate morning orders
            System.out.println("\nProcessing morning orders...");
            orderQueue.enqueue(new Order("Table 1", "Pancakes", 2));
            orderQueue.enqueue(new Order("Table 3", "Omelette", 1));
            orderQueue.enqueue(new Order("Table 2", "French Toast", 3));
            
            System.out.println("Current orders in queue: " + orderQueue.size());
            System.out.println("Next order to prepare: " + orderQueue.first());

            // Process orders
            System.out.println("\nKitchen starting to cook orders:");
            while (!orderQueue.isEmpty()) {
                Order currentOrder = orderQueue.dequeue();
                System.out.println("Preparing: " + currentOrder);
            }

            System.out.println("\nAll morning orders completed!");
            System.out.println("Orders remaining in queue: " + orderQueue.size());

        } catch (IllegalStateException e) {
            System.out.println("Kitchen overwhelmed: " + e.getMessage());
        }
    }

    private static void testPeakHourOperations() {
        System.out.println("\n=== Peak Hour Stress Test ===");
        CircularArrayQueue<Order> orderQueue = new CircularArrayQueue<>(3);

        try {
            // Simulate lunch rush
            System.out.println("Lunch rush beginning...");
            orderQueue.enqueue(new Order("Table 5", "Burger", 2));
            orderQueue.enqueue(new Order("Table 6", "Pizza", 1));
            orderQueue.enqueue(new Order("Table 7", "Salad", 1));
            
            // This should trigger queue full exception
            System.out.println("Attempting to add order when queue is full...");
            orderQueue.enqueue(new Order("Table 8", "Sandwich", 1));

        } catch (IllegalStateException e) {
            System.out.println("Kitchen backup alert: " + e.getMessage());
            System.out.println("Manager needs to help in kitchen!");
        }

        // Process backed up orders
        System.out.println("\nProcessing backed up orders:");
        while (!orderQueue.isEmpty()) {
            System.out.println("Completed: " + orderQueue.dequeue());
        }
    }

    // Inner class to represent a restaurant order
    private static class Order {
        private String tableNumber;
        private String dishName;
        private int quantity;

        public Order(String table, String dish, int qty) {
            this.tableNumber = table;
            this.dishName = dish;
            this.quantity = qty;
        }

        @Override
        public String toString() {
            return String.format("%s - %dx %s", tableNumber, quantity, dishName);
        }
    }
}
package csc311;
import net.datastructures.Position;

public class TestClasses {
    public static void main(String[] args) {
        System.out.println("=== Library Management System Tests ===\n");
        testBookInventory();
        testCheckoutQueue();
        testReadingList();
    }

    // Testing ArrayList implementation with book inventory
    private static void testBookInventory() {
        System.out.println("📚 Testing Book Inventory Management...");
        ArrayList<String> bookShelf = new ArrayList<>();
        
        // Adding books to different sections
        System.out.println("Adding books to inventory...");
        bookShelf.add(0, "The Great Gatsby - Fiction Section");
        bookShelf.add(1, "Brief History of Time - Science Section");
        bookShelf.add(2, "Art of Programming - Computer Science");
        bookShelf.add(3, "Pride and Prejudice - Classics Section");
        
        System.out.println("Total books in inventory: " + bookShelf.size());
        
        // Simulating book rearrangement
        System.out.println("\nMoving 'Brief History of Time' to featured section...");
        String featured = bookShelf.get(1);
        bookShelf.remove(1);
        bookShelf.add(0, featured);
        
        System.out.println("Current featured book: " + bookShelf.get(0));
        System.out.println("Second book on shelf: " + bookShelf.get(1));
        
        // Testing inventory update
        bookShelf.set(2, "Clean Code - Computer Science");
        System.out.println("\nUpdated computer science section: " + bookShelf.get(2));
    }

    // Testing CircularArrayQueue with library checkout system
    private static void testCheckoutQueue() {
        System.out.println("\n🔄 Testing Library Checkout Queue...");
        CircularArrayQueue<String> checkoutLine = new CircularArrayQueue<>(5);
        
        // Simulating patrons joining checkout queue
        System.out.println("Patrons joining the checkout line...");
        checkoutLine.enqueue("Alice (checking out 3 books)");
        checkoutLine.enqueue("Bob (returning 2 books)");
        checkoutLine.enqueue("Charlie (new library card)");
        
        System.out.println("People waiting in line: " + checkoutLine.size());
        System.out.println("Next patron to serve: " + checkoutLine.first());
        
        // Processing checkout
        System.out.println("\nServing next patron...");
        String servedPatron = checkoutLine.dequeue();
        System.out.println("Now serving: " + servedPatron);
        System.out.println("Next in line: " + checkoutLine.first());
        
        // Testing queue capacity
        checkoutLine.enqueue("David (book reservation)");
        checkoutLine.enqueue("Eva (late fee payment)");
        
        if (checkoutLine.size() >= 5) {
            System.out.println("\nCheckout line is full - requesting additional staff!");
        }
    }

    // Testing DoublyLinkedList with reading list management
    private static void testReadingList() {
        System.out.println("\n📖 Testing Reading List Manager...");
        DoublyLinkedList<String> readingList = new DoublyLinkedList<>();
        
        // Building reading list
        System.out.println("Creating summer reading list...");
        readingList.addFirst("1984 (High Priority)");
        Position<String> middleBook = readingList.addLast("Dune (Medium Priority)");
        readingList.addLast("The Hobbit (Low Priority)");
        
        // Testing list navigation
        System.out.println("First book to read: " + readingList.first().getElement());
        System.out.println("Last book on list: " + readingList.last().getElement());
        
        // Adding recommendations
        System.out.println("\nAdding friend's recommendation...");
        readingList.addBefore(middleBook, "Foundation (Friend's Pick)");
        readingList.addAfter(middleBook, "Neuromancer (Bonus Read)");
        
        // Marking book as read
        System.out.println("\nFinished reading first book!");
        readingList.remove(readingList.first());
        System.out.println("Next book to read: " + readingList.first().getElement());
        
        // Displaying full reading list
        System.out.println("\nCurrent reading list:");
        for (String book : readingList) {
            System.out.println("- " + book);
        }
    }
}